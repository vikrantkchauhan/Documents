package in.sp.services;

public class BankTransactions
{
	public void transactionUsingUpi()
	{
		System.out.println("====== business logic for UPI transaction ======");
	}
}