package in.sp.services;

public class BankTransactions
{
	public void transactionUsingUpi()
	{
		System.out.println("====== business logic for UPI transaction ======");
	}
	
	public void transactionUsingInternetBanking()
	{
		System.out.println("====== business logic for Internet Banking transaction ======");
	}
	
	public void transactionUsingWallet()
	{
		System.out.println("====== business logic for Wallet transaction ======");
	}
}