package in.sp.services;

public class PaytmTransactions
{
	public void walletTransactions()
	{
		System.out.println("====== business logic for wallet transactions ======");
	}
}
