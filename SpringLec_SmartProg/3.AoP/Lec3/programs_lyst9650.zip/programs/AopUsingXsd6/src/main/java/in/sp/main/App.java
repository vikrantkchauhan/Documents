package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import in.sp.services.BankTransactions;
import in.sp.services.PaytmTransactions;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("/in/sp/resources/applicationContext.xml");
        
        BankTransactions bt = (BankTransactions) context.getBean("bankTransId");
        
        bt.transactionUsingUpi();
        System.out.println();
        
        bt.transactionUsingInternetBanking();
        System.out.println();
        
        bt.transactionUsingMobileBanking();
        System.out.println();
        
        //--------------------------------------------------------
        
        PaytmTransactions pt = (PaytmTransactions) context.getBean("paytmTransId");
        pt.walletTransactions();
    }
}
