package in.sp.aspects;

public class LoggingAspect
{
	public void myLogging()
	{
		System.out.println("------ before logging ------");
	}
}