package in.sp.aspects;

public class SecurityAspect
{
	public void mySecurity()
	{
		System.out.println("------ security service ------");
	}
}