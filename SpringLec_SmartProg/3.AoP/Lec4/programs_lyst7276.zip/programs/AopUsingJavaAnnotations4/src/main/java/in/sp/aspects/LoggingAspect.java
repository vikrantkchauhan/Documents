package in.sp.aspects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LoggingAspect 
{
	@Around("execution(* in.sp.services.BankTransactions.transactionUsingMobileBanking(..)) || "+
			"execution(* in.sp.services.BankTransactions.transactionUsingInternetBanking(..))")
	public void myLogging(ProceedingJoinPoint joinPoint) throws Throwable
	{
		System.out.println("------ logging service (before) ------");
		
		joinPoint.proceed();
		
		System.out.println("------ logging service (after) ------");
	}
}