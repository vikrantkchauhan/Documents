package in.sp.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import in.sp.aspects.LoggingAspect;
import in.sp.services.BankTransactions;
import in.sp.services.PaytmTransactions;

@Configuration
@EnableAspectJAutoProxy
public class SpringConfigFile 
{
	@Bean
	public BankTransactions bankTrans()
	{
		return new BankTransactions();
	}
	
	@Bean
	public PaytmTransactions paytmTrans()
	{
		return new PaytmTransactions();
	}
	
	@Bean
	public LoggingAspect logAspect()
	{
		return new LoggingAspect();
	}
}