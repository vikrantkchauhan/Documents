package in.sp.services;

public class PaytmTransactions 
{
	public void transactionUsingWallet()
	{
		System.out.println("====== business logic for Paytm Wallet transaction ======");
	}
}
