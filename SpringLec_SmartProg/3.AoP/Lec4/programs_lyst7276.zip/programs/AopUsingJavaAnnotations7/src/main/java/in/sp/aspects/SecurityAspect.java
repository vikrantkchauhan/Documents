package in.sp.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class SecurityAspect 
{
	@Before("execution(* in.sp.services.BankTransactions.*(..)) || "+
			"execution(* in.sp.services.PaytmTransactions.*(..))")
	public void mySecurity()
	{
		System.out.println("------ security service ------");
	}
}
