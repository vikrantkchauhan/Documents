package in.sp.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAspect 
{
	//@Before("execution(* in.sp.services.BankTransactions.transactionUsingMobileBanking(..)) || execution(* in.sp.services.BankTransactions.transactionUsingInternetBanking(..))")
	@Before("execution(* in.sp.services.BankTransactions.transactionUsingMobileBanking(..)) || "+
			"execution(* in.sp.services.BankTransactions.transactionUsingInternetBanking(..))")
	public void myLogging()
	{
		System.out.println("------ logging service ------");
	}
}