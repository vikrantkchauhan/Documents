package in.sp.services;

public class BankTransactions 
{
	public void transactionUsingUpi()
	{
		System.out.println("====== business logic for UPI transactions ======");
	}
	
	public void transactionUsingMobileBanking()
	{
		System.out.println("====== business logic for Mobile Banking transactions ======");
	}
	
	public void transactionUsingInternetBanking()
	{
		System.out.println("====== business logic for Internet Banking transactions ======");
	}
}
