package in.sp.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import in.sp.aspects.LoggingAspect;
import in.sp.services.BankTransactions;

@Configuration
@EnableAspectJAutoProxy
public class SpringConfigFile 
{
	@Bean
	public BankTransactions bankTrans()
	{
		return new BankTransactions();
	}
	
	@Bean
	public LoggingAspect logAspect()
	{
		return new LoggingAspect();
	}
}