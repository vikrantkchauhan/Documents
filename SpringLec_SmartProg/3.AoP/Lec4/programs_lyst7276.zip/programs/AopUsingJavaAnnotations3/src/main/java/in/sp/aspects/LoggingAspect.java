package in.sp.aspects;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAspect 
{
	@Before("execution(* in.sp.services.BankTransactions.transactionUsingMobileBanking(..)) || "+
			"execution(* in.sp.services.BankTransactions.transactionUsingInternetBanking(..))")
	public void myLoggingBefore()
	{
		System.out.println("------ logging service (before) ------");
	}
	
	@After("execution(* in.sp.services.BankTransactions.transactionUsingMobileBanking(..)) || "+
			"execution(* in.sp.services.BankTransactions.transactionUsingInternetBanking(..))")
	public void myLoggingAfter()
	{
		System.out.println("------ logging service (after) ------");
	}
}