package in.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductApiTask1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductApiTask1Application.class, args);
	}

}
