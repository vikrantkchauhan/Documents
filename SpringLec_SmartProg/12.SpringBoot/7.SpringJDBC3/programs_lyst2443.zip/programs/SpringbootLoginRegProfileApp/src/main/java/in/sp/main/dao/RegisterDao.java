package in.sp.main.dao;

import in.sp.main.beans.Student;

public interface RegisterDao
{
	public boolean registerDao(Student std);
}
