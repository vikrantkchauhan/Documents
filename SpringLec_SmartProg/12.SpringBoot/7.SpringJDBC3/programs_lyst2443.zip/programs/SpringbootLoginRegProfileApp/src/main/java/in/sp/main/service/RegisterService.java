package in.sp.main.service;

import in.sp.main.beans.Student;

public interface RegisterService 
{
	public boolean registerService(Student std);
}
