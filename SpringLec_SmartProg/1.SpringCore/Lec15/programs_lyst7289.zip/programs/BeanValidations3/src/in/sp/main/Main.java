package in.sp.main;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;

import in.sp.beans.Student;
import in.sp.validators.StudentValidator;

public class Main 
{
	public static void main(String[] args)
	{
		String configLocation = "/in/sp/resources/applicationContext.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
		
		Student std = (Student) context.getBean("stdId");
		
		Map<String, Object> map = new HashMap<String, Object>();
		MapBindingResult mapBindingResult = new MapBindingResult(map, "mymapobj");
		
		StudentValidator stdValidator = (StudentValidator) context.getBean("stdValId");
		stdValidator.validate(std, mapBindingResult);
		
		List<ObjectError> list = mapBindingResult.getAllErrors();
		
		if(list.isEmpty())
		{
			std.display();
		}
		else
		{
			for(ObjectError oe : list)
			{
				System.err.println(oe.getDefaultMessage());
			}
		}
	}
}
