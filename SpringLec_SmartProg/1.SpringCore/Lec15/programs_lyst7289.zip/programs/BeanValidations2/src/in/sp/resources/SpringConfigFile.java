package in.sp.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import in.sp.beans.Student;

@Configuration
public class SpringConfigFile 
{
	@Bean("stdId")
	public Student createStdObj()
	{
		Student std = new Student();
		
		std.setName("Amit");
		std.setRollno(222);
		std.setPhoneno("6283830308");
		
		return std;
	}
}