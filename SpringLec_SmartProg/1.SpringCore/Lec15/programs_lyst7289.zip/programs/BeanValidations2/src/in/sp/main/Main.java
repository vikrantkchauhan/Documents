package in.sp.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.DataBinder;
import org.springframework.validation.ObjectError;

import in.sp.beans.Student;
import in.sp.resources.SpringConfigFile;
import in.sp.validators.StudentValidator;

public class Main 
{
	public static void main(String[] args)
	{
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
		
		Student std = (Student) context.getBean("stdId");
		
		DataBinder dataBinder = new DataBinder(std);
		dataBinder.addValidators(new StudentValidator());
		dataBinder.validate();
		
		List<ObjectError> list = dataBinder.getBindingResult().getAllErrors();
		
		if(list.isEmpty())
		{
			std.display();
		}
		else
		{
			for(ObjectError oe : list)
			{
				System.err.println(oe.getDefaultMessage());
			}
		}
	}
}
