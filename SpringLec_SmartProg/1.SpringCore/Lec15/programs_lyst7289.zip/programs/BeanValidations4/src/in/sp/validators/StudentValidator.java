package in.sp.validators;

import java.util.Properties;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import in.sp.beans.Student;

public class StudentValidator implements Validator
{
	private Resource resource;
	public void setResource(Resource resource) {
		this.resource = resource;
	}

	@Override
	public boolean supports(Class<?> clazz) 
	{
		boolean b = Student.class.equals(clazz);
		return b;
	}

	@Override
	public void validate(Object target, Errors errors) 
	{
		try
		{
			Student std = (Student) target;
			
			Properties properties = PropertiesLoaderUtils.loadProperties(resource);
			
			if(std.getName().equals("") || std.getName().equals("null"))
			{
				errors.rejectValue("name", "key_name", properties.getProperty("key_name"));
			}
			if(std.getRollno()<=0)
			{
				errors.rejectValue("rollno", "key_rollno", properties.getProperty("key_rollno"));
			}
			if(std.getPhoneno().length() != 10)
			{
				errors.rejectValue("phoneno", "key_phoneno", properties.getProperty("key_phoneno"));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
