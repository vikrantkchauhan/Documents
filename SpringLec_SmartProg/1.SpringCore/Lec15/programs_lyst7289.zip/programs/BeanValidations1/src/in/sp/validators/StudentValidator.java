package in.sp.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import in.sp.beans.Student;

public class StudentValidator implements Validator
{
	@Override
	public boolean supports(Class<?> clazz) 
	{
		boolean b = Student.class.equals(clazz);
		return b;
	}

	@Override
	public void validate(Object target, Errors errors) 
	{
		Student std = (Student) target;
		
		if(std.getName().equals("") || std.getName().equals("null"))
		{
			errors.rejectValue("name", "key_name", "Name is not valid");
		}
		if(std.getRollno()<=0)
		{
			errors.rejectValue("rollno", "key_rollno", "Rollno is not valid");
		}
		if(std.getPhoneno().length() != 10)
		{
			errors.rejectValue("phoneno", "key_phoneno", "Phone no is not valid");
		}
	}
}
