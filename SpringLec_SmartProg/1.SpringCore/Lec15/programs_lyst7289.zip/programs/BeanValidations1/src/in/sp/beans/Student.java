package in.sp.beans;

public class Student
{
	private String name;
	private int rollno;
	private String phoneno;
	
	public void setName(String name) {
		this.name = name;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	
	public String getName() {
		return name;
	}
	public int getRollno() {
		return rollno;
	}
	public String getPhoneno() {
		return phoneno;
	}
	
	public void display()
	{
		System.out.println("Name : "+name);
		System.out.println("Rollno : "+rollno);
		System.out.println("Phone No. : "+phoneno);
	}
}
