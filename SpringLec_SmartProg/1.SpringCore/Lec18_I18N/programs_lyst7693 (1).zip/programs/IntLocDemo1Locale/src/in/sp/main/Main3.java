package in.sp.main;

import java.util.Locale;

public class Main3
{
	public static void main(String[] args)
	{
		//Locale mylocale = Locale.JAPANESE;
		//Locale mylocale = Locale.CHINESE;
		Locale mylocale = new Locale("hi");
		
		String[] countryCode_Arr = Locale.getISOCountries();
		for(String countryCode : countryCode_Arr)
		{
			Locale locale = new Locale("", countryCode);
			System.out.println(countryCode+" -> "+locale.getDisplayCountry()+" - "+locale.getDisplayCountry(mylocale));
		}
	}
}