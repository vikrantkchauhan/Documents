package in.sp.main;

import java.util.Locale;

public class Main2
{
	public static void main(String[] args)
	{
//		String[] countryCode_arr = Locale.getISOCountries();
//		for(String countryCode : countryCode_arr)
//		{
//			Locale locale = new Locale("", countryCode);
//			System.out.println(countryCode+" -> "+locale.getDisplayCountry());
//		}
		
		System.out.println("-----------------------------------------------");
		
		String[] langaugeCode_arr = Locale.getISOLanguages();
		for(String languageCode : langaugeCode_arr)
		{
			Locale locale = new Locale(languageCode);
			System.out.println(languageCode+" -> "+locale.getDisplayLanguage());
		}
	}
}
