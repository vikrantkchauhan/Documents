package in.sp.main;

import java.util.Currency;
import java.util.Locale;

public class Main1 
{
	public static void main(String[] args) 
	{
		Locale locale1 = Locale.getDefault();
		Currency currency = Currency.getInstance(locale1);
		System.out.println(currency.getSymbol()+" -> "+currency.getDisplayName());
		
		System.out.println("\n------------Below is for France-------------");
		Locale locale2 = new Locale("fr", "FR");
		Currency currency2 = Currency.getInstance(locale2);
		System.out.println(currency2.getSymbol()+" -> "+currency2.getDisplayName());
		
		
		System.out.println("\n------------Below is for USA-------------");
		Locale locale3 = new Locale("eg", "US");
		Currency currency3 = Currency.getInstance(locale3);
		System.out.println(currency3.getSymbol()+" -> "+currency3.getDisplayName());
	}
}
