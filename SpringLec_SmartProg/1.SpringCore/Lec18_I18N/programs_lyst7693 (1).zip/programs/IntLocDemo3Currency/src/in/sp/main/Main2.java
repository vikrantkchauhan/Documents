package in.sp.main;

import java.text.NumberFormat;
import java.util.Locale;

public class Main2 
{
	public static void main(String[] args)
	{
		int no1 = 123456789;
		double no2 = 98765.43210;
		
		Locale locale1 = Locale.getDefault();
		
		NumberFormat nf1 = NumberFormat.getCurrencyInstance(locale1);
		System.out.println(nf1.format(no1));
		System.out.println(nf1.format(no2));
		
		
		System.out.println("----------------Currency for USA--------------");
		Locale locale2 = new Locale("en", "US");
		NumberFormat nf2 = NumberFormat.getCurrencyInstance(locale2);
		System.out.println(nf2.format(no1));
		System.out.println(nf2.format(no2));
		
		
		System.out.println("----------------Currency for Franec--------------");
		Locale locale3 = new Locale("fr", "FR");
		NumberFormat nf3 = NumberFormat.getCurrencyInstance(locale3);
		System.out.println(nf3.format(no1));
		System.out.println(nf3.format(no2));
	}
}
