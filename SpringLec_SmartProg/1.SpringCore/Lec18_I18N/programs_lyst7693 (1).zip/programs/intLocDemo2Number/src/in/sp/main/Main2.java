package in.sp.main;

import java.text.DecimalFormat;

public class Main2
{
	public static void main(String[] args)
	{
		int no1 = 123456789;
		double no2 = 9876.543210;
		
		//String pattern = "######.#####";
		//String pattern = "######.##";
		//String pattern = "##,##,##.#####";
		String pattern = "###,###.#####";
		
		DecimalFormat dm1 = new DecimalFormat(pattern);
		System.out.println(dm1.format(no1));
		System.out.println(dm1.format(no2));
	}
}
