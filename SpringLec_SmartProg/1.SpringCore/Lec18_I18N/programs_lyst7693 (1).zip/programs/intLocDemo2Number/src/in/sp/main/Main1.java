package in.sp.main;

import java.text.NumberFormat;
import java.util.Locale;

public class Main1
{
	public static void main(String[] args)
	{
		int no1 = 123456789;
		double no2 = 98765.43210;
		
		System.out.println("--------------Below is Indian Format------------------");
		Locale locale1 = Locale.getDefault();
		NumberFormat nf1 = NumberFormat.getInstance(locale1);
		System.out.println(nf1.format(no1));
		System.out.println(nf1.format(no2));
		
		
		System.out.println("--------------Below is France Format------------------");
		Locale locale2 = new Locale("fr", "FR");
		NumberFormat nf2 = NumberFormat.getInstance(locale2);
		System.out.println(nf2.format(no1));
		System.out.println(nf2.format(no2));
		
		
		System.out.println("--------------Below is Argentina Format------------------");
		Locale locale3 = new Locale("es", "AR");
		NumberFormat nf3 = NumberFormat.getInstance(locale3);
		System.out.println(nf3.format(no1));
		System.out.println(nf3.format(no2));
	}
}
