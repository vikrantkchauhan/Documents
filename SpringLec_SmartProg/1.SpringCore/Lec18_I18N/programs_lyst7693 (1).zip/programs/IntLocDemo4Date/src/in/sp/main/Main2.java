package in.sp.main;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Main2 
{
	public static void main(String[] args) 
	{
		Date date = new Date();
		
		//System.out.println(date);
		
		//String pattern = "dd/MM/yyyy";
		//String pattern = "dd/MMM/yyyy";
		//String pattern = "dd/MMM/yy";
		//String pattern = "dd MM yyyy";
		//String pattern = "dd MMM yyyy";
		//String pattern = "dd-MM-yyyy";
		//String pattern = "dd-MMM-yyyy HH:mm:ss";
		String pattern = "dd-MMM-yyyy hh:mm:ss aa";
		
		SimpleDateFormat sdf1 = new SimpleDateFormat(pattern);
		System.out.println(sdf1.format(date));
	}
}
