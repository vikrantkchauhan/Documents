package in.sp.main;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class Main1
{
	public static void main(String[] args)
	{
		Date date = new Date();
		
		System.out.println(date);
		System.out.println();
		
		
		System.out.println("----------Below is Indian Format-----------");
		Locale locale1 = new Locale("en", "IN");
		DateFormat df1 = DateFormat.getDateInstance(0, locale1);
		System.out.println(df1.format(date));
		
		
		System.out.println("\n----------Below is USA Format-----------");
		Locale locale2 = new Locale("en", "US");
		DateFormat df2 = DateFormat.getDateInstance(0, locale2);
		System.out.println(df2.format(date));
		
		
		System.out.println("\n----------Below is France Format-----------");
		Locale locale3 = new Locale("fr", "FR");
		DateFormat df3 = DateFormat.getDateInstance(0, locale3);
		System.out.println(df3.format(date));
		
		
		System.out.println("\n----------Below is Argentina Format-----------");
		Locale locale4 = new Locale("es", "AR");
		DateFormat df4 = DateFormat.getDateInstance(0, locale4);
		System.out.println(df4.format(date));
	}
}
