package in.sp.main2;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class Main
{
	public static void main(String[] args)
	{
		ExpressionParser parsor = new SpelExpressionParser();
		
		
//		Expression expression = parsor.parseExpression(" T(in.sp.main2.MyClass).m1('aaa') ");
//		expression.getValue();
		
		
		Expression expression = parsor.parseExpression(" new in.sp.main2.MyClass().m2(111) ");
		expression.getValue();
	}
}
