package in.sp.main1;

public class MyClass
{
	public static void m1()
	{
		System.out.println("m1() static method");
	}
	
	public void m2()
	{
		System.out.println("m2() instance method");
	}
	
	public static int m3()
	{
		return 111;
	}
}
