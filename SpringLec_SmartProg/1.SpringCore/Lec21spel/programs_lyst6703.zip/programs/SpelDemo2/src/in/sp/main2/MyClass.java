package in.sp.main2;

public class MyClass
{
	public static void m1(String str)
	{
		System.out.println("str : "+str);
	}
	
	public void m2(int no)
	{
		System.out.println("no : "+no);
	}
}
