package in.sp.beans;

public class Student
{
	private String name;
	private String aadharno;
	private String phoneno;

	public void setName(String name) {
		this.name = name;
	}
	public void setAadharno(String aadharno) {
		this.aadharno = aadharno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public void stdDisplay()
	{
		System.out.println("Student Name : "+name);
		System.out.println("Student Aadhar No. : "+aadharno);
		System.out.println("Student Phone No. : "+phoneno);
	}
}
