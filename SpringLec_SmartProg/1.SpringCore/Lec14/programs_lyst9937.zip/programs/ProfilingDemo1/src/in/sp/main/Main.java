package in.sp.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import in.sp.beans.Student;

public class Main 
{
	public static void main(String[] args)
	{
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("/in/sp/resources/applicationContext.xml");
		
		context.getEnvironment().setActiveProfiles("development");
		context.refresh();
		
		Student std = (Student) context.getBean("stdId");
		std.display();
	}
}
