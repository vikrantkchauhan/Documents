package in.sp.beans;

public class Calculations
{
	public void add(int a, int b)
	{
		int res = a+b;
		System.out.println("Addition is : "+res);
	}
}