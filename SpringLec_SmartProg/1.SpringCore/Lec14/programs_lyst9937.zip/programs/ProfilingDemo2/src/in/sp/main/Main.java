package in.sp.main;

import org.springframework.context.support.GenericXmlApplicationContext;

import in.sp.beans.Student;

public class Main
{
	public static void main(String[] args)
	{
		System.setProperty("spring.profiles.active", "production");
		
		String[] resourceLocation= {
				"/in/sp/resources/applicationContext-development.xml",
				"/in/sp/resources/applicationContext-testing.xml",
				"/in/sp/resources/applicationContext-production.xml"
		};
		GenericXmlApplicationContext context = new GenericXmlApplicationContext();
		context.load(resourceLocation);
		context.refresh();
		
		Student std = (Student) context.getBean("stdId");
		std.display();
	}
}
