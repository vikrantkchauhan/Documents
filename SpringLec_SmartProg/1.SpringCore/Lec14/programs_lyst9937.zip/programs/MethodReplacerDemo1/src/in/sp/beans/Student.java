package in.sp.beans;

public class Student
{
	public void display()
	{
		System.out.println("How are you ?");
	}
}
