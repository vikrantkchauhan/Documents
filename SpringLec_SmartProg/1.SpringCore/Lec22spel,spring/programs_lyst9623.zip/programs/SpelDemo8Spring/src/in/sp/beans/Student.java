package in.sp.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("stdId")
public class Student
{
	@Value("Amit")
	private String name;
	
	@Value("#{addrId.getCity()}")
	private String city;
	
	public void setName(String name) {
		this.name = name;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public void display()
	{
		System.out.println("Name : "+name);
		System.out.println("City : "+city);
	}
}
