package in.sp.beans;

public class Student
{
	private String name;
	private float marks;
	
	public void setName(String name) {
		this.name = name;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	
	public void display()
	{
		System.out.println("Hello "+name+", you got total "+marks+" marks");
	}
}
