package in.sp.main;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import in.sp.beans.Student;

public class Main 
{
	public static void main(String[] args)
	{
		PropertyConfigurator.configure(System.getProperty("user.dir")+"/src/in/sp/resources/log4j.properties");
		
		Logger logger = Logger.getLogger("Main");
		logger.fatal("this is fatal message");
		logger.warn("this is warning message");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("/in/sp/resources/applicationContext.xml");
		
		Student std = (Student) context.getBean("stdId");
		std.display();
	}
}
