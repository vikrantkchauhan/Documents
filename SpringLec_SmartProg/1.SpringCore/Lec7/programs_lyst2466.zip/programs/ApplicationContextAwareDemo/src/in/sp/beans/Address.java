package in.sp.beans;

public class Address
{
	private String city;
	private String zipcode;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	@Override
	public String toString() 
	{
		return "City : "+city+", Zipcode : "+zipcode;
	}
}
