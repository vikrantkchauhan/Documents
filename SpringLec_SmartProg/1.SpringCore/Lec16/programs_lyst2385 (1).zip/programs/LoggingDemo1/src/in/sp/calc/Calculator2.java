package in.sp.calc;

import java.io.IOException;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Calculator2
{
	public static void main(String[] args) throws IOException
	{
		FileHandler fileHandler = new FileHandler("d:\\calc2.log", true);
		SimpleFormatter simpleFormatter = new SimpleFormatter();
		fileHandler.setFormatter(simpleFormatter);
		
		Logger logger = Logger.getLogger("Calculator1");
		logger.addHandler(fileHandler);
		
		Scanner scanner = new Scanner(System.in);
		
		String continue_calc="";
		do
		{
			logger.log(Level.INFO, "====================================================");
			
			System.out.println("Enter no1");
			int no1 = scanner.nextInt();
			logger.log(Level.INFO, "user has provided no1 i.e. "+no1);
			
			System.out.println("Enter no2");
			int no2 = scanner.nextInt();
			logger.log(Level.INFO, "user has provided no2 i.e. "+no2);
			
			System.out.println("Select Any One Symbol (+, -, *, /)");
			String symbol = scanner.next();
			logger.log(Level.INFO, "user has provided symbol i.e. "+symbol);
			
			int res;
			
			switch(symbol)
			{
				case "+":
					res = no1+no2;
					System.out.println("Sum is : "+res);
					logger.log(Level.INFO, "result is "+res);
					break;
					
				case "-":
					res = no1-no2;
					System.out.println("Sub is : "+res);
					logger.log(Level.INFO, "result is "+res);
					break;
					
				case "*":
					res = no1*no2;
					System.out.println("Multiplication is : "+res);
					logger.log(Level.INFO, "result is "+res);
					break;
					
				case "/":
					if(no2==0)
					{
						logger.log(Level.SEVERE, "You cannot divide by zero");
						System.out.println("You cannot divide by zero");
					}
					else
					{
						res = no1/no2;
						System.out.println("Division is : "+res);
						logger.log(Level.INFO, "result is "+res);
					}
					
					break;
					
				default:
					System.out.println("Invalid symbol");
					logger.log(Level.INFO, "Invalid symbol");
			}
			System.out.println("Do you want to continue, press y for yes else any key to exit");
			continue_calc = scanner.next();
		}
		while(continue_calc.equals("y") || continue_calc.equals("Y"));
	}
}
