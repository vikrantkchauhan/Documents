package in.sp.logging;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Test1 
{
	public static void main(String[] args) 
	{
		System.out.println("hello 1");
		
		//get the logger object
		Logger logger = Logger.getLogger("Test1");
		
		logger.log(Level.SEVERE, "Server is not responding");
		logger.log(Level.WARNING, "3 invalid login attempts");
		logger.log(Level.INFO, "this is information message");
		
		System.out.println("hello 2");
	}
}
