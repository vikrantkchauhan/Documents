package in.sp.logging;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Test3 
{
	public static void main(String[] args) 
	{
		try
		{
			System.out.println("hello 1");
			
			FileHandler fileHandler = new FileHandler("D:\\mydemo.log");
			SimpleFormatter simpleFormatter = new SimpleFormatter();
			fileHandler.setFormatter(simpleFormatter);
			
			Logger logger = Logger.getLogger("Test1");
			logger.addHandler(fileHandler);
			
			logger.log(Level.SEVERE, "Server is not responding");
			logger.log(Level.WARNING, "3 invalid login attempts");
			logger.log(Level.INFO, "this is information message");
			
			System.out.println("hello 2");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
