package in.sp.beans;

import java.util.Locale;

import org.springframework.context.MessageSource;

public class Student 
{
	private String name;
	private String country;
	private MessageSource msgsource;
	
	public void setName(String name) {
		this.name = name;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setMsgsource(MessageSource msgsource) {
		this.msgsource = msgsource;
	}

	public void display()
	{
		//Locale locale = new Locale("hi", "IN");
		Locale locale = new Locale("en", "US");
		
		String message = msgsource.getMessage("key_message", new Object[] {name, country}, locale);
		
		System.out.println(message);
	}
}