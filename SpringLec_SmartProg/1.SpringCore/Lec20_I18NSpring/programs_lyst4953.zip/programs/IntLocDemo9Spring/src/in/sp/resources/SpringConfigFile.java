package in.sp.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

import in.sp.beans.Student;

@Configuration
public class SpringConfigFile 
{
	@Bean
	public ResourceBundleMessageSource rsmSrcId()
	{
		ResourceBundleMessageSource obj = new ResourceBundleMessageSource();
		obj.setBasename("in/sp/resources/MessageBundle");
		
		return obj;
	}
	
	@Bean
	public Student stdId()
	{
		Student std = new Student();
		std.setMsgsource(rsmSrcId());
		
		return std;
	}
}

/*

	<bean class="org.springframework.context.support.ResourceBundleMessageSource" id="rsmSrcId">
		<property name="basename" value="in/sp/resources/MessageBundle" />
	</bean>
	
	@Bean
	public ResourceBundleMessageSource rsmSrcId()
	{
		ResourceBundleMessageSource obj = new ResourceBundleMessageSource();
		obj.setBasename("in/sp/resources/MessageBundle");
		
		return obj;
	}
	
	==================================================================================

    <bean class="in.sp.beans.Student" id="stdId">
    	<property name="msgsource" ref="rsmSrcId" />
    </bean>
    
    @Bean
	public Student stdId()
	{
		Student std = new Student();
		std.setMsgsource(rsmSrcId());
		
		return std;
	}

*/