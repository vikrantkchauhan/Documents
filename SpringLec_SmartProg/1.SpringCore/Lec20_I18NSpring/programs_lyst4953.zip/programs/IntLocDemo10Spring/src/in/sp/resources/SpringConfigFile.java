package in.sp.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

import in.sp.beans.Student;

@Configuration
public class SpringConfigFile
{
	@Bean
	public ResourceBundleMessageSource rbmSrcId()
	{
		ResourceBundleMessageSource obj = new ResourceBundleMessageSource();
		obj.setBasename("in/sp/resources/MessageBundle");
		
		return obj;
	}
	
	@Bean
	public Student stdId()
	{
		Student std = new Student();
		std.setName("Deepesh");
		std.setCountry("India");
		std.setMsgsource(rbmSrcId());
		
		return std;
	}
}


/*

	<bean class="org.springframework.context.support.ResourceBundleMessageSource" id="rsmSrcId">
		<property name="basename" value="in/sp/resources/MessageBundle" />
	</bean>
	
	@Bean
	public ResourceBundleMessageSource rbmSrcId()
	{
		ResourceBundleMessageSource obj = new ResourceBundleMessageSource();
		obj.setBasename("in/sp/resources/MessageBundle");
		
		return obj;
	}
	
	
	=================================================================================

    <bean class="in.sp.beans.Student" id="stdId">
    	<property name="name" value="Amit" />
    	<property name="country" value="India" />
    	<property name="msgsource" ref="rsmSrcId" />
    </bean>
    
    @Bean
	public Student stdId()
	{
		Student std = new Student();
		std.setName("Deepesh");
		std.setCountry("India");
		std.setMsgsource(rbmSrcId());
		
		return std;
	}

*/