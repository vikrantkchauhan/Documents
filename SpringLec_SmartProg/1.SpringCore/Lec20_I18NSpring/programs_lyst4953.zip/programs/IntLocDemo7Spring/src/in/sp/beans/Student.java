package in.sp.beans;

import java.util.Locale;

import org.springframework.context.MessageSource;

public class Student 
{
	private MessageSource msgsource;
	public void setMsgsource(MessageSource msgsource) {
		this.msgsource = msgsource;
	}

	public void display()
	{
		Locale locale = new Locale("hi", "IN");
		String message = msgsource.getMessage("key_message", null, locale);
		
		System.out.println(message);
	}
}