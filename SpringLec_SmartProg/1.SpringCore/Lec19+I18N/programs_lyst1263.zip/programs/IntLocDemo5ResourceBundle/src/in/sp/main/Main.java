package in.sp.main;

import java.util.Locale;
import java.util.ResourceBundle;

public class Main 
{
	public static void main(String[] args)
	{
		//Locale locale = new Locale("en", "US");
		Locale locale = new Locale("hi", "IN");
		//Locale locale = new Locale("fr", "FR");
		
		ResourceBundle resourceBundle = ResourceBundle.getBundle("in/sp/resources/MessageBundle", locale);
		
		String msg = resourceBundle.getString("key_greet");
		System.out.println(msg);
	}
}