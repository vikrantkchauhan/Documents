package in.sp.main;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Choose ny one option from below :-");
		System.out.println("1. English - US");
		System.out.println("2. Hindi - India");
		System.out.println("-----------------------------------------------");
		
		int no = scanner.nextInt();
		
		switch(no)
		{
			case 1 : 
				ChooseLocale.localeDetails("en", "US");
				break;
				
			case 2 : 
				ChooseLocale.localeDetails("hi", "IN");
				break;
				
			default:
				System.out.println("Invalid Input");
				break;
		}
	}
}
