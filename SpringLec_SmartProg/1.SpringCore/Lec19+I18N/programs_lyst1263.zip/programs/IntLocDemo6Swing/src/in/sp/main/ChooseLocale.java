package in.sp.main;

import java.util.Locale;
import java.util.ResourceBundle;

public class ChooseLocale
{
	static void localeDetails(String languageCode, String countryCode)
	{
		Locale locale = new Locale(languageCode, countryCode);
		
		ResourceBundle resourceBundle = ResourceBundle.getBundle("in/sp/resources/MessageBundle", locale);
		
		String key_login_title = resourceBundle.getString("key_login_title");
		String key_email_title = resourceBundle.getString("key_email_title");
		String key_pass_title = resourceBundle.getString("key_pass_title");
		String key_login_btn = resourceBundle.getString("key_login_btn");
		
		new LoginFrame(key_login_title, key_email_title, key_pass_title, key_login_btn);
	}
}
