package in.sp.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

//This class is used to configure the security filter chain properly

public class SecurityWebAppInitializer extends AbstractSecurityWebApplicationInitializer
{

}