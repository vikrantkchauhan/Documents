package in.sp.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

//in replacement of spring-security.xml file

@EnableWebSecurity
@ComponentScan("in.sp.controllers")
public class WebSecurityConfig extends WebSecurityConfigurerAdapter
{
	@Override
	protected void configure(HttpSecurity http) throws Exception 
	{
		http
			.authorizeRequests()
				.antMatchers("/adminPanel").hasRole("ADMIN")
				.and()
			.formLogin();
	}
	
	@Bean
	@Override
	protected UserDetailsService userDetailsService()
	{
		UserDetails ud = User.withUsername("admin").password("$2a$12$XlY8ye1g8HpHUYl8CkCeSOn4GLuYAfT0IgQtkfNcwCPmgdmBcJ1O.").roles("ADMIN").build();
		
		InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
		manager.createUser(ud);
		
		return manager;
	}
	
	@Bean
	public PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
}
