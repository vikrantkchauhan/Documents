package in.sp.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.sp.beans.Employee;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure("/in/sp/resources/hibernate.cfg.xml");
        
        SessionFactory sessionFactory = cfg.buildSessionFactory();
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        
        try
        {
        	Employee emp = session.get(Employee.class, 101);
        	emp.setEmpdept("Python Developer");
        	
        	session.update(emp);
        	System.out.println("success");
        	
        	transaction.commit();
        }
        catch(Exception e)
        {
        	System.out.println("fail");
        	transaction.rollback();
        	
        	e.printStackTrace();
        }
        finally
        {
			session.close();
			sessionFactory.close();
		}
    }
}
