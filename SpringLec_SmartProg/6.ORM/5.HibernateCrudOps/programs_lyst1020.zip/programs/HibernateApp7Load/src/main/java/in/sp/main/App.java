package in.sp.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.sp.beans.Employee;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure("/in/sp/resources/hibernate.cfg.xml");
        
        SessionFactory sessionFactory = cfg.buildSessionFactory();
        
        Session session = sessionFactory.openSession();
        
        try
        {
//        	Employee emp = session.load(Employee.class, 101);
        	
        	Employee emp = (Employee) session.load("in.sp.beans.Employee", 104);
//        	System.out.println(emp);
        	
//        	System.out.println("Employee Id : "+emp.getEmpid());
//        	System.out.println("Employee Name : "+emp.getEmpname());
//        	System.out.println("Employee Dept : "+emp.getEmpdept());
//        	System.out.println("Employee City : "+emp.getEmpcity());
        }
        catch(Exception e)
        {
        	System.out.println("fail");
        	
        	e.printStackTrace();
        }
        finally
        {
			session.close();
			sessionFactory.close();
		}
    }
}
