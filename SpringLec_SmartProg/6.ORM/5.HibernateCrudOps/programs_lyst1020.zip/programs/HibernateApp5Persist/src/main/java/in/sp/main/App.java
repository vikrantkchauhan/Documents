package in.sp.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.sp.beans.Employee;

public class App 
{
    public static void main( String[] args )
    {
        Employee emp = new Employee();
        emp.setEmpid(103);
        emp.setEmpname("rahul");
        emp.setEmpdept("Java Developer");
        emp.setEmpcity("delhi");
        
        //--------------------------------------------------------
        
        Configuration cfg = new Configuration();
        cfg.configure("/in/sp/resources/hibernate.cfg.xml");
        
        SessionFactory sessionFactory = cfg.buildSessionFactory();
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        
        try
        {
//        	int id = (int) session.save(emp);
//        	System.out.println("Id : "+id);
        	
        	session.persist(emp);
        	System.out.println("success");
        	
        	transaction.commit();
        }
        catch(Exception e)
        {
        	System.out.println("fail");
        	transaction.rollback();
        	
        	e.printStackTrace();
        }
        finally
        {
			session.close();
			sessionFactory.close();
		}
    }
}
