package in.sp.main;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        DataSource dataSource = context.getBean(DataSource.class);
        
        Connection con1 = dataSource.getConnection();
        Connection con2 = dataSource.getConnection();
        Connection con3 = dataSource.getConnection();
        Connection con4 = dataSource.getConnection();
        Connection con5 = dataSource.getConnection();
        
        con1.close();
        con2.close();
        
        Connection con6 = dataSource.getConnection();
        Connection con7 = dataSource.getConnection();
        
        System.out.println("success");
    }
}
