package in.sp.main;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.zaxxer.hikari.HikariDataSource;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        HikariDataSource dataSource = context.getBean(HikariDataSource.class);
        
        Connection con1 = dataSource.getConnection();
        Connection con2 = dataSource.getConnection();
        Connection con3 = dataSource.getConnection();
        Connection con4 = dataSource.getConnection();
        Connection con5 = dataSource.getConnection();
        
        con1.close();
        con2.close();
        con3.close();
        
        Connection con6 = dataSource.getConnection();
        Connection con7 = dataSource.getConnection();
        
        int active_connections = dataSource.getHikariPoolMXBean().getActiveConnections();
        int idle_connections = dataSource.getHikariPoolMXBean().getIdleConnections();
        int total_connections = dataSource.getHikariPoolMXBean().getTotalConnections();
        
        System.out.println("Active Connections : "+active_connections);
        System.out.println("Idle Connections : "+idle_connections);
        System.out.println("Total Connections : "+total_connections);
        
        System.out.println("success");
    }
}
