package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        
        String sql_query = "insert into items values(?,?,?)";
        Object[] params1 = {101, "shirt", 500};
        Object[] params2 = {102, "t-shirt", 600};
        
        int count1 = jdbcTemplate.update(sql_query, params1);
        int count2 = jdbcTemplate.update(sql_query, params2);
        
        if(count1>0 && count2>0)
        {
        	System.out.println("success");
        }
        else
        {
        	System.out.println("fail");
        }
    }
}
