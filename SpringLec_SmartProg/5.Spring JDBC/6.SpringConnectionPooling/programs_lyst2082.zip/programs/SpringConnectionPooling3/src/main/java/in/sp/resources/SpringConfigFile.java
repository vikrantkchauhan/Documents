package in.sp.resources;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class SpringConfigFile
{
	@Bean
	public DataSource createDataSourceObj()
	{
		HikariConfig config = new HikariConfig();
		config.setJdbcUrl("jdbc:mysql://localhost:3306/shopping_app");
		config.setUsername("root");
		config.setPassword("root");
		config.setMaximumPoolSize(5);
		
		HikariDataSource hikariDataSource = new HikariDataSource(config);
		return hikariDataSource;
	}
	
	@Bean
	public JdbcTemplate createJdbcTemplateObj()
	{
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(createDataSourceObj());
		return jdbcTemplate;
	}
}
