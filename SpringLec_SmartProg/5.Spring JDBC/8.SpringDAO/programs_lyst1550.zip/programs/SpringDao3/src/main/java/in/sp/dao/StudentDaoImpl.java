package in.sp.dao;

import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class StudentDaoImpl extends NamedParameterJdbcDaoSupport implements StudentDao
{
	@Override
	public boolean addStdDetailsDao(Map<String, Object> map) 
	{
		boolean status = false;
		
		try
		{
			String sql_query = "insert into register values(:key_name, :key_email, :key_pass, :key_gender, :key_city)";
			int count = getNamedParameterJdbcTemplate().update(sql_query, map);
			if(count > 0)
			{
				status = true;
			}
			else
			{
				status = false;
			}
		}
		catch(Exception e)
		{
			status = false;
			e.printStackTrace();
		}
		
		return status;
	}
}
