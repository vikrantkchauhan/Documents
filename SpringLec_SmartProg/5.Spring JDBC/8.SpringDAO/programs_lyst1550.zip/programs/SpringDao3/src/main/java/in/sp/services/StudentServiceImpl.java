package in.sp.services;

import java.util.Map;
import in.sp.dao.StudentDao;

public class StudentServiceImpl implements StudentService
{
	private StudentDao stdDao;
	public void setStdDao(StudentDao stdDao) {
		this.stdDao = stdDao;
	}

	@Override
	public boolean addStdDetailsService(Map<String, Object> map) 
	{
		boolean status = stdDao.addStdDetailsDao(map);
		return status;
	}
}
