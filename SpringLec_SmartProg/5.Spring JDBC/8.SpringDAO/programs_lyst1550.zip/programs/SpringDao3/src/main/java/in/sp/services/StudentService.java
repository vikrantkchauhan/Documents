package in.sp.services;

import java.util.Map;

public interface StudentService 
{
	public boolean addStdDetailsService(Map<String, Object> map);
}