package in.sp.main;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import in.sp.resources.SpringConfigFile;
import in.sp.services.StudentService;
import in.sp.services.StudentServiceImpl;

public class App 
{
    public static void main( String[] args )
    {
    	Map<String, Object> map = new HashMap<String, Object>();
		
    	map.put("key_name", "ggg");
    	map.put("key_email", "ggg@gmail.com");
    	map.put("key_pass", "ggg123");
    	map.put("key_gender", "male");
    	map.put("key_city", "chandigarh");
    	
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        StudentService stdService = context.getBean(StudentServiceImpl.class);
        boolean status = stdService.addStdDetailsService(map);
        if(status)
        {
        	System.out.println("success");
        }
        else
        {
        	System.out.println("fail");
        }
    }
}
