package in.sp.dao;

import java.util.Map;

public interface StudentDao 
{
	public boolean addStdDetailsDao(Map<String, Object> map);
}
