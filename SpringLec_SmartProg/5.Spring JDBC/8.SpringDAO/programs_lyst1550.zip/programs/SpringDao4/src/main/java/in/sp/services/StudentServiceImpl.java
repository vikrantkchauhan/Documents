package in.sp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.beans.Student;
import in.sp.dao.StudentDao;

@Service
public class StudentServiceImpl implements StudentService
{
	@Autowired
	private StudentDao stdDao;
	public void setStdDao(StudentDao stdDao) {
		this.stdDao = stdDao;
	}

	@Override
	public boolean addStdDetailsService(Student std) 
	{
		boolean status = stdDao.addStdDetailsDao(std);
		return status;
	}
}
