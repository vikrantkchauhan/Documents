package in.sp.resources;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import in.sp.beans.Student;
import in.sp.dao.StudentDaoImpl;
import in.sp.services.StudentServiceImpl;

@Configuration
public class SpringConfigFile 
{
	@Bean
	public DataSource createDataSourceObj()
	{
		DriverManagerDataSource dmDataSource = new DriverManagerDataSource();
		
		dmDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dmDataSource.setUrl("jdbc:mysql://localhost:3306/dao_db");
		dmDataSource.setUsername("root");
		dmDataSource.setPassword("root");
		
		return dmDataSource;
	}
	
	@Bean
	public JdbcTemplate createJdbcTemplateObj()
	{
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(createDataSourceObj());
		return jdbcTemplate;
	}
	
	@Bean
	public StudentDaoImpl createStdDaoImplObj()
	{
		StudentDaoImpl stdDaoImpl = new StudentDaoImpl();
		stdDaoImpl.setJdbcTemplate(createJdbcTemplateObj());
		return stdDaoImpl;
	}
	
	@Bean
	public StudentServiceImpl createStdServiceImplObj()
	{
		StudentServiceImpl stdServiceImpl = new StudentServiceImpl();
		stdServiceImpl.setStdDao(createStdDaoImplObj());
		return stdServiceImpl;
	}
	
//	@Bean
//	public Student createStdObj()
//	{
//		Student std = new Student();
//		
//		std.setName("ddd");
//		std.setEmail("ddd@gmail.com");
//		std.setPassword("ddd123");
//		std.setGender("female");
//		std.setCity("delhi");
//		
//		return std;
//	}
}