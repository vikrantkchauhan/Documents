package in.sp.dao;

import in.sp.beans.Student;

public interface StudentDao 
{
	public boolean addStdDetailsDao(Student std);
}
