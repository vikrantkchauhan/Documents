package in.sp.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.beans.Student;

public class StudentDaoImpl implements StudentDao
{
	private JdbcTemplate jdbcTemplate;
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public boolean addStdDetailsDao(Student std) 
	{
		boolean status = false;
		
		try
		{
			String sql_query = "insert into register values(?,?,?,?,?)";
			int count = jdbcTemplate.update(sql_query, std.getName(), std.getEmail(), std.getPassword(), std.getGender(), std.getCity());
			if(count > 0)
			{
				status = true;
			}
			else
			{
				status = false;
			}
		}
		catch(Exception e)
		{
			status = false;
			e.printStackTrace();
		}
		
		return status;
	}
}
