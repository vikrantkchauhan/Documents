package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import in.sp.beans.Student;
import in.sp.resources.SpringConfigFile;
import in.sp.services.StudentService;
import in.sp.services.StudentServiceImpl;

public class App 
{
    public static void main( String[] args )
    {
		Student std = new Student();
		
		std.setName("eee");
		std.setEmail("eee@gmail.com");
		std.setPassword("eee123");
		std.setGender("female");
		std.setCity("mumbai");
    	
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        //Student std = context.getBean(Student.class);
        
        StudentService stdService = context.getBean(StudentServiceImpl.class);
        boolean status = stdService.addStdDetailsService(std);
        if(status)
        {
        	System.out.println("success");
        }
        else
        {
        	System.out.println("fail");
        }
    }
}
