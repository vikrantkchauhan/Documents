package in.sp.services;

import in.sp.beans.Student;

public interface StudentService 
{
	public boolean addStdDetailsService(Student std);
}