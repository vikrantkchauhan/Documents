package in.sp.main;

import in.sp.beans.Student;
import in.sp.dao.StudentDao;
import in.sp.dao.StudentDaoImpl;

public class Main
{
	public static void main(String[] args)
	{
		Student std = new Student();
		std.setName("bbb");
		std.setEmail("bbb@gmail.com");
		std.setPassword("bbb123");
		std.setGender("male");
		std.setCity("pune");
		
		StudentDao stdDao = new StudentDaoImpl();
		boolean status = stdDao.addStdDetails(std);
		if(status)
		{
			System.out.println("success");
		}
		else
		{
			System.out.println("fail");
		}
	}
}
