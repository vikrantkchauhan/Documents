package in.sp.service;

import in.sp.beans.Student;
import in.sp.dao.StudentDao;
import in.sp.dao.StudentDaoImpl;

public class StudentServiceImpl implements StudentService
{
	@Override
	public boolean addStdDetailsService(Student std) 
	{
		StudentDao stdDao = new StudentDaoImpl();
		boolean status = stdDao.addStdDetails(std);
		return status;
	}
}
