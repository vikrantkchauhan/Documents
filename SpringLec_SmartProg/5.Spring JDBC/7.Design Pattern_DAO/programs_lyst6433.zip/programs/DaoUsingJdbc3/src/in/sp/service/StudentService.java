package in.sp.service;

import in.sp.beans.Student;

public interface StudentService
{
	public boolean addStdDetailsService(Student std);
}
