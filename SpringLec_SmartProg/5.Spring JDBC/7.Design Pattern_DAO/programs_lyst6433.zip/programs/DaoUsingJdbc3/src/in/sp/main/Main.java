package in.sp.main;

import in.sp.beans.Student;
import in.sp.service.StudentService;
import in.sp.service.StudentServiceImpl;

public class Main
{
	public static void main(String[] args)
	{
		Student std = new Student();
		std.setName("ccc");
		std.setEmail("ccc@gmail.com");
		std.setPassword("ccc123");
		std.setGender("female");
		std.setCity("pune");
		
		StudentService stdService = new StudentServiceImpl();
		boolean status = stdService.addStdDetailsService(std);
		if(status)
		{
			System.out.println("success");
		}
		else
		{
			System.out.println("fail");
		}
	}
}
