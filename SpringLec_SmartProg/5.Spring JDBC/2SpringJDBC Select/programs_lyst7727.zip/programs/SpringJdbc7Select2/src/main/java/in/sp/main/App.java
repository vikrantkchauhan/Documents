package in.sp.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.beans.Item;
import in.sp.mappers.ItemRowMapper;
import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        
        
        //------------------1-------------------------------------------------
//        String sql_query = "select item_name, item_price from items";
//        List<Item> list_item = jdbcTemplate.query(sql_query, new ItemRowMapper());
//        //System.out.println(list_item);
//        for(Item item : list_item)
//        {
//        	System.out.println(item.getItemname()+" - "+item.getItemprice());
//        	System.out.println("---------------");
//        }
        
        
        //-----------------2--------------------------------------------------
        int myitemid = 101;
        
        String sql_query = "select item_name, item_price from items where item_id=?";
        List<Item> list_item = jdbcTemplate.query(sql_query, new ItemRowMapper(), myitemid);
        //System.out.println(list_item);
        for(Item item : list_item)
        {
        	System.out.println(item.getItemname()+" - "+item.getItemprice());
        	System.out.println("---------------");
        }
    }
}
