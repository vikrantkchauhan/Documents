package in.sp.main;

import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        
        String sql_query = "select * from items";
        List<Map<String, Object>> list = jdbcTemplate.queryForList(sql_query);
        //System.out.println(list);
        for(Map<String, Object> map : list)
        {
        	System.out.println(map.get("item_id")+" - "+map.get("item_name")+" - "+map.get("item_price"));
        	System.out.println("----------------------------");
        }
    }
}
