package in.sp.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import in.sp.beans.Item;

public class ItemRowMapper implements RowMapper<Item>
{
	@Override
	public Item mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		Item item = new Item();
		
		item.setItemid(rs.getInt("item_id"));
		item.setItemname(rs.getString("item_name"));
		item.setItemprice(rs.getInt("item_price"));
		
		return item;
	}
}
