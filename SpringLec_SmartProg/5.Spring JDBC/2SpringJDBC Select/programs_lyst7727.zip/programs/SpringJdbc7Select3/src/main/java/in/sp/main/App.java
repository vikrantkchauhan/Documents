package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.beans.Item;
import in.sp.mappers.ItemRowMapper;
import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        
        int itemid = 104;
        
        String sql_query = "select * from items where item_id=?";
        Item item = jdbcTemplate.queryForObject(sql_query, new ItemRowMapper(), itemid);
        System.out.println(item.getItemid()+" - "+item.getItemname()+" - "+item.getItemprice());
    }
}