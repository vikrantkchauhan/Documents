package in.sp.main;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        
        int itemid = 101;
        String sql_query = "select * from items where item_id=?";
        Map<String, Object> map = jdbcTemplate.queryForMap(sql_query, itemid);
        System.out.println(map);
    }
}