package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
    	int item_id = 103;
    	String item_name = "t-shirt";
    	int item_price = 699;
    	
    	ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
    	
    	JdbcTemplate jdbcTemplate = (JdbcTemplate) context.getBean("myJdbcTemplate");
    	
    	//------------------ way 1----------------------------
//    	String sql_query = "insert into items values('"+item_id+"', '"+item_name+"', '"+item_price+"')";
//    	int count = jdbcTemplate.update(sql_query);
//    	if(count > 0)
//    	{
//    		System.out.println("success");
//    	}
//    	else
//    	{
//    		System.out.println("fail");
//    	}
    	
    	
    	//------------------ way 2----------------------------
//    	String sql_query = "insert into items values(?,?,?)";
//    	int count = jdbcTemplate.update(sql_query, item_id, item_name, item_price);
//    	if(count > 0)
//    	{
//    		System.out.println("success");
//    	}
//    	else
//    	{
//    		System.out.println("fail");
//    	}
    	
    	
    	//------------------ way 3----------------------------
    	String sql_query = "insert into items values(?,?,?)";
    	int count = jdbcTemplate.update(sql_query, new Object[] {item_id, item_name, item_price});
    	if(count > 0)
    	{
    		System.out.println("success");
    	}
    	else
    	{
    		System.out.println("fail");
    	}
    }
}