package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
    	int item_id = 103;
    	int item_price = 1099;
    	
    	ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
    	
    	JdbcTemplate jdbcTemplate = (JdbcTemplate) context.getBean("myJdbcTemplate");
    	
    	String sql_query = "update items set item_price=? where item_id=?";
    	int count = jdbcTemplate.update(sql_query, item_price, item_id);
    	if(count > 0)
    	{
    		System.out.println("success");
    	}
    	else
    	{
    		System.out.println("fail");
    	}
    }
}