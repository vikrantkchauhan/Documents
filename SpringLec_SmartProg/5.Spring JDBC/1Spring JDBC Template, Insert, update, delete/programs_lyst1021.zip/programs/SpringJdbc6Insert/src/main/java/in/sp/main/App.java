package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.beans.Items;
import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {    	
    	ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
    	
    	JdbcTemplate jdbcTemplate = (JdbcTemplate) context.getBean("myJdbcTemplate");
    	
    	Items items = context.getBean(Items.class);
    	
    	String sql_query = "insert into items values(?,?,?)";
    	int count = jdbcTemplate.update(sql_query, items.getItemid(), items.getItemname(), items.getItemprice());
    	if(count > 0)
    	{
    		System.out.println("success");
    	}
    	else
    	{
    		System.out.println("fail");
    	}
    }
}