package in.sp.resources;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class SpringConfigFile
{
	@Bean
	public DataSource createDataSourceObj()
	{
		DriverManagerDataSource dmDataSource = new DriverManagerDataSource();
		
		dmDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dmDataSource.setUrl("jdbc:mysql://localhost:3306/shopping_app");
		dmDataSource.setUsername("root");
		dmDataSource.setPassword("root");
		
		return dmDataSource;
	}
	
	@Bean
	public JdbcTemplate createJdbcTemplateObj()
	{
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(createDataSourceObj());
		return jdbcTemplate;
	}
}
