package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        
        
        //-------------------1-------------------------------------------------------
//        String query1 = "insert into items values(101, 'shirt', 500)";
//        String query2 = "insert into items values(102, 't-shirt', 600)";
//        String query3 = "insert into items values(103, 'jeans', 700)";
//        
//        int[] count = jdbcTemplate.batchUpdate(query1, query2, query3);
//        for(int i : count)
//        {
//        	System.out.println(i+" : success");
//        }
        
        
        
        //-------------------2-----------------------------------------------------
        String query1 = "insert into items values(101, 'shirt', 500)";
        String query2 = "insert into items values(102, 't-shirt', 600)";
        String query3 = "insert into items values(103, 'jeans', 700)";
        
        String[] queries = {query1, query2, query3};
        
        int[] count = jdbcTemplate.batchUpdate(queries);
        for(int i : count)
        {
        	System.out.println(i+" : success");
        }
    }
}