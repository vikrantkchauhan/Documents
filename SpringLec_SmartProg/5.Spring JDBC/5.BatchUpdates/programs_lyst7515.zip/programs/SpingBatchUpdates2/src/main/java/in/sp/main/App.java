package in.sp.main;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import in.sp.beans.Items;
import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
    	Items item1 = new Items();
    	item1.setItemid(101);
    	item1.setItemname("shirt");
    	item1.setItemprice(500);
    	
    	Items item2 = new Items();
    	item2.setItemid(102);
    	item2.setItemname("t-shirt");
    	item2.setItemprice(700);
    	
    	Items item3 = new Items();
    	item3.setItemid(103);
    	item3.setItemname("jeans");
    	item3.setItemprice(900);
    	
    	final List<Items> items_list = new ArrayList<Items>();
    	items_list.add(item1);
    	items_list.add(item2);
    	items_list.add(item3);
    	
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        
        String sql_query = "insert into items values(?,?,?)";
        int[] count = jdbcTemplate.batchUpdate(sql_query, new BatchPreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps, int index) throws SQLException
			{
				Items item = items_list.get(index);
				
				ps.setInt(1, item.getItemid());
				ps.setString(2, item.getItemname());
				ps.setInt(3, item.getItemprice());
			}
			
			@Override
			public int getBatchSize() 
			{
				return items_list.size();
			}
		});
        
        for(int i : count)
        {
        	System.out.println(i+" : success");
        }
    }
}