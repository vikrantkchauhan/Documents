package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
//    	MapSqlParameterSource params = new MapSqlParameterSource();
//    	params.addValue("key_id", 106);
//    	params.addValue("key_name", "coat-pent");
//    	params.addValue("key_price", 8999);
    	
    	MapSqlParameterSource params = new MapSqlParameterSource();
    	params.addValue("key_id", 107)
    			.addValue("key_name", "top")
    			.addValue("key_price", 999);
    	
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        NamedParameterJdbcTemplate npJdbcTemplate = context.getBean(NamedParameterJdbcTemplate.class);
        
        String sql_query = "insert into items values(:key_id, :key_name, :key_price)";
        int count = npJdbcTemplate.update(sql_query, params);
        if(count > 0)
        {
        	System.out.println("success");
        }
        else
        {
        	System.out.println("fail");
        }
    }
}
