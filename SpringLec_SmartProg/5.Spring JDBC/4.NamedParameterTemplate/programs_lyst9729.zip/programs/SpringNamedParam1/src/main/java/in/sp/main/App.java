package in.sp.main;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put("key_id", 105);
    	map.put("key_name", "kurta");
    	map.put("key_price", 1199);
    	
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        NamedParameterJdbcTemplate npJdbcTemplate = context.getBean(NamedParameterJdbcTemplate.class);
        
        String sql_query = "insert into items values(:key_id, :key_name, :key_price)";
        int count = npJdbcTemplate.update(sql_query, map);
        if(count > 0)
        {
        	System.out.println("success");
        }
        else
        {
        	System.out.println("fail");
        }
    }
}
