package in.sp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import in.sp.beans.Items;
import in.sp.resources.SpringConfigFile;

public class App 
{
    public static void main( String[] args )
    {
    	Items items = new Items();
    	items.setItemid(108);
    	items.setItemname("lehnga");
    	items.setItemprice(20000);
    	
    	BeanPropertySqlParameterSource params = new BeanPropertySqlParameterSource(items);
    	
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        NamedParameterJdbcTemplate npJdbcTemplate = context.getBean(NamedParameterJdbcTemplate.class);
        
        String sql_query = "insert into items values(:itemid, :itemname, :itemprice)";
        int count = npJdbcTemplate.update(sql_query, params);
        if(count > 0)
        {
        	System.out.println("success");
        }
        else
        {
        	System.out.println("fail");
        }
    }
}
